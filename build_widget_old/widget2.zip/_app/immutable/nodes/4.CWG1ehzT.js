import"../chunks/CWj6FrbW.js";import"../chunks/69_IOA4Y.js";function t(o){}export{t as component};
