import{h as s,a as l}from"./DG9Qoy50.js";function h(n,a,r,t,d){var i;s&&l();var e=(i=a.$$slots)==null?void 0:i[r],f=!1;e===!0&&(e=a.children,f=!0),e===void 0||e(n,f?()=>t:t)}export{h as s};
