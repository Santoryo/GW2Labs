import{s as e,p as r}from"./DR8M-zDs.js";const s={get error(){return r.error},get status(){return r.status},get url(){return r.url}};e.updated.check;export{s as p};
