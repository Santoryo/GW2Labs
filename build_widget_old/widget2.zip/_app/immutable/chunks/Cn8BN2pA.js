import{p}from"./BLJDfXis.js";const o=p;export{o as p};
